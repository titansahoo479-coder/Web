/* ==========================================================================
   Basic Client-Side Hardening
   NOTE: Real security (data validation, access control) must always happen
   on the server / Firestore rules. This file only adds light UX deterrents
   and must never block page load, script execution, or navigation.
   ========================================================================== */

(function () {
    'use strict';

    // Disable right-click context menu (cosmetic deterrent only)
    document.addEventListener('contextmenu', function (e) {
        e.preventDefault();
    });

    // Disable common "view source / devtools" shortcuts (cosmetic deterrent only)
    document.addEventListener('keydown', function (e) {
        const key = e.key ? e.key.toUpperCase() : '';
        const blockedCombo =
            key === 'F12' ||
            (e.ctrlKey && e.shiftKey && (key === 'I' || key === 'J' || key === 'C')) ||
            (e.ctrlKey && key === 'U');

        if (blockedCombo) {
            e.preventDefault();
        }
    });
})();
