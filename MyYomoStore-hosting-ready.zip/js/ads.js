/* ==========================================================================
   Advertisements Loader — Adsterra
   ==========================================================================
   HOW TO DISABLE ADS:
   Each ad has its own on/off switch below. Set any one to false (or
   comment out its whole block) to disable just that ad — the other
   keeps working independently.
   ========================================================================== */

const AD_SLOT_1_ENABLED = true; // Ad 1: profitablecpmratenetwork
const AD_SLOT_1_SRC = "https://pl29329358.profitablecpmratenetwork.com/75/a8/46/75a846c1e4f95f73fb12983d7ad08b10.js";

const AD_SLOT_2_ENABLED = true; // Ad 2: effectivecpmnetwork
const AD_SLOT_2_SRC = "https://pl29890677.effectivecpmnetwork.com/39/9b/67/399b67c63e24d8dfb59f4ee2945ed4c8.js";

(function () {
    'use strict';

    function loadAdScript(src) {
        try {
            const adScript = document.createElement('script');
            adScript.src = src;
            adScript.async = true;
            adScript.type = 'text/javascript';
            document.body.appendChild(adScript);
        } catch (e) {
            console.error('Ad script failed to load:', src, e);
        }
    }

    if (AD_SLOT_1_ENABLED) {
        loadAdScript(AD_SLOT_1_SRC);
    }

    if (AD_SLOT_2_ENABLED) {
        loadAdScript(AD_SLOT_2_SRC);
    }
})();