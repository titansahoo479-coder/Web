/* ==========================================================================
   Index Page Main Controller
   - 1.5s failsafe guard so the page never loads forever
   - Realtime Firestore sync with graceful fallback to local demo data
   - Retry mechanism if both realtime sync and fallback somehow fail
   ========================================================================== */

let globalAppsArray = [];
let homeRendered = false;
let unsubscribeAppsList = null;

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    setupSearchLogic();
    startHomeDataFlow();

    if (window.lucide) {
        lucide.createIcons();
    }
});

function startHomeDataFlow() {
    homeRendered = false;

    // 1.5s Strict Guard — never let the loading skeleton spin forever
    const homeTimeout = setTimeout(() => {
        if (!homeRendered) {
            homeRendered = true;
            globalAppsArray = (typeof localAppsData !== 'undefined') ? localAppsData : [];
            renderApps(globalAppsArray);
        }
    }, 1500);

    try {
        subscribeSettings(
            (data) => updateStorefrontBranding(data),
            () => applyDefaultBranding()
        );
    } catch (e) {
        console.error('subscribeSettings error:', e);
        applyDefaultBranding();
    }

    try {
        unsubscribeAppsList = subscribeAppsList(
            (apps) => {
                homeRendered = true;
                clearTimeout(homeTimeout);
                globalAppsArray = apps;
                renderApps(apps);
            },
            () => {
                if (!homeRendered) {
                    homeRendered = true;
                    clearTimeout(homeTimeout);
                    globalAppsArray = (typeof localAppsData !== 'undefined') ? localAppsData : [];
                    renderApps(globalAppsArray);
                }
            }
        );
    } catch (e) {
        console.error('subscribeAppsList error:', e);
        if (!homeRendered) {
            homeRendered = true;
            clearTimeout(homeTimeout);
            globalAppsArray = (typeof localAppsData !== 'undefined') ? localAppsData : [];
            renderApps(globalAppsArray);
        }
    }
}

function setupSearchLogic() {
    const btnSearchToggle = document.getElementById('btn-search-toggle');
    const searchContainer = document.getElementById('search-container');
    const searchInput = document.getElementById('search-input');
    let isSearchActive = false;

    if (btnSearchToggle && searchContainer && searchInput) {
        btnSearchToggle.addEventListener('click', () => {
            isSearchActive = !isSearchActive;
            if (isSearchActive) {
                searchContainer.classList.add('active');
                btnSearchToggle.innerHTML = `<i data-lucide="x" style="width: 18px; height: 18px;"></i>`;
                if (window.lucide) lucide.createIcons();
                setTimeout(() => searchInput.focus(), 100);
            } else {
                searchContainer.classList.remove('active');
                btnSearchToggle.innerHTML = `<i data-lucide="search" style="width: 18px; height: 18px;"></i>`;
                if (window.lucide) lucide.createIcons();
                searchInput.value = '';
                renderApps(globalAppsArray);
            }
        });

        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                const keyword = e.target.value.toLowerCase().trim();
                const filteredApps = globalAppsArray.filter(app =>
                    (app.name && app.name.toLowerCase().includes(keyword)) ||
                    (app.version && app.version.toLowerCase().includes(keyword))
                );
                renderApps(filteredApps);
            }, 60);
        });
    }
}

function renderApps(apps) {
    const skeletonLoader = document.getElementById('skeleton-loader');
    const appList = document.getElementById('app-list');

    if (skeletonLoader) skeletonLoader.style.display = 'none';
    if (!appList) return;

    appList.style.display = 'flex';
    appList.innerHTML = '';

    if (!apps || apps.length === 0) {
        appList.innerHTML = `
            <div class="empty-state">
                <i data-lucide="folder-open" style="width: 48px; height: 48px;"></i>
                <p style="font-size: 14px;">No premium apps listed.</p>
            </div>
        `;
        if (window.lucide) lucide.createIcons();
        return;
    }

    apps.forEach(app => {
        const card = document.createElement('div');
        card.className = 'app-card';
        card.id = `card-${app.id}`;

        const appSlug = app.name ? encodeURIComponent(app.name.toLowerCase().replace(/\s+/g, '-')) : 'app';
        const pageLink = `download.html?app=${appSlug}&id=${encodeURIComponent(app.id)}`;

        card.innerHTML = `
            <div class="app-card-left">
                <img src="${app.icon}" class="app-icon" alt="${app.name}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?w=150&q=80'">
                <div class="app-info">
                    <span class="app-name">${app.name}</span>
                    <span class="app-version">${app.version || 'v1.0.0'}</span>
                </div>
            </div>

            <a href="${pageLink}" class="btn-download">
                <i data-lucide="download" style="width: 15px; height: 15px;"></i>
                <span>GET</span>
            </a>
        `;
        appList.appendChild(card);
    });

    if (window.lucide) lucide.createIcons();
}
