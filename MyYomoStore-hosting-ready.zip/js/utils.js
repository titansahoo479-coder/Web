/* ==========================================================================
   Utility Functions
   - Theme (dark/light) handling with localStorage persistence
   - Toast notifications
   - URL query parameter helper
   ========================================================================== */

/**
 * Reads a query parameter from the current page URL.
 * Works on first load AND on refresh/direct-open because it reads
 * window.location.search fresh every time it's called.
 */
function getQueryParam(name) {
    try {
        const params = new URLSearchParams(window.location.search);
        return params.get(name);
    } catch (e) {
        console.error('getQueryParam error:', e);
        return null;
    }
}

/**
 * Initializes theme on page load based on saved preference (defaults to dark).
 */
function initTheme() {
    try {
        const savedTheme = localStorage.getItem('theme') || 'dark';
        document.documentElement.setAttribute('data-theme', savedTheme);
        updateThemeIcon(savedTheme);

        const themeToggleBtn = document.getElementById('btn-theme-toggle');
        if (themeToggleBtn) {
            themeToggleBtn.addEventListener('click', () => {
                const current = document.documentElement.getAttribute('data-theme') || 'dark';
                const next = current === 'dark' ? 'light' : 'dark';
                document.documentElement.setAttribute('data-theme', next);
                localStorage.setItem('theme', next);
                updateThemeIcon(next);
            });
        }
    } catch (e) {
        console.error('initTheme error:', e);
    }
}

/**
 * Updates the moon/sun icon to reflect current theme.
 */
function updateThemeIcon(theme) {
    const icon = document.getElementById('theme-icon');
    if (!icon) return;
    icon.setAttribute('data-lucide', theme === 'dark' ? 'moon' : 'sun');
    if (window.lucide) {
        lucide.createIcons();
    }
}

/**
 * Shows a small toast notification for a few seconds.
 */
function showToast(message) {
    const toast = document.getElementById('toast-alert');
    const toastMessage = document.getElementById('toast-message');
    if (!toast || !toastMessage) return;

    toastMessage.innerText = message;
    toast.classList.add('active');

    setTimeout(() => {
        toast.classList.remove('active');
    }, 3000);
}
