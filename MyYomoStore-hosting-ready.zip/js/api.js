/* ==========================================================================
   Data Access API Layer
   Local demo data acts as the fallback/offline dataset when Firestore
   is unreachable or returns no documents.
   ========================================================================== */

const localAppsData = [
    {
        id: "demo1",
        name: "Premium Photo Editor",
        version: "v4.5.2",
        size: "45 MB",
        updatedAt: "2026-02-10",
        downloadsCount: "12K+",
        description: "Professional photo editing suite featuring AI enhancements, color grading filters, and advanced layer tools.",
        icon: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&q=80",
        download: "https://example.com/editor"
    },
    {
        id: "demo2",
        name: "Apex Launcher Plus",
        version: "v10.0.1",
        size: "18 MB",
        updatedAt: "2026-01-25",
        downloadsCount: "45K+",
        description: "Fast, customizable launcher with smart widgets, gesture controls, and custom icon pack integrations.",
        icon: "https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?w=150&q=80",
        download: "https://example.com/apex"
    },
    {
        id: "demo3",
        name: "YOMO Music Player Pro",
        version: "v1.0.4",
        size: "28 MB",
        updatedAt: "2026-03-01",
        downloadsCount: "8K+",
        description: "Ultra-high fidelity music player with equalizer presets, lyrics integration, and seamless cloud syncing.",
        icon: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&q=80",
        download: "https://example.com/music"
    }
];

/**
 * Subscribes to realtime storefront settings (branding) from Firestore.
 * Returns the unsubscribe function, or undefined if Firestore isn't active.
 */
function subscribeSettings(onSuccess, onError) {
    try {
        const activeDb = getFirestoreDb();
        if (activeDb) {
            return activeDb.collection("config").doc("settings").onSnapshot((doc) => {
                if (doc.exists) {
                    onSuccess(doc.data());
                } else {
                    onError();
                }
            }, (error) => {
                console.error('subscribeSettings snapshot error:', error);
                onError();
            });
        } else {
            onError();
        }
    } catch (e) {
        console.error('subscribeSettings error:', e);
        onError();
    }
}

/**
 * Subscribes to the realtime list of apps from Firestore.
 * Returns the unsubscribe function, or undefined if Firestore isn't active.
 */
function subscribeAppsList(onSuccess, onError) {
    try {
        const activeDb = getFirestoreDb();
        if (activeDb) {
            return activeDb.collection("apps").onSnapshot((snapshot) => {
                const fetchedApps = [];
                snapshot.forEach((doc) => {
                    fetchedApps.push({ id: doc.id, ...doc.data() });
                });
                onSuccess(fetchedApps);
            }, (error) => {
                console.error('subscribeAppsList snapshot error:', error);
                onError();
            });
        } else {
            onError();
        }
    } catch (e) {
        console.error('subscribeAppsList error:', e);
        onError();
    }
}