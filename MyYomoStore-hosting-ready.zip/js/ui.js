/* ==========================================================================
   UI / Branding Controller
   Applies dynamic storefront branding (logo, site name, footer text)
   coming from Firestore "config/settings", with a safe static fallback
   so the page never looks broken while Firestore is slow or unavailable.

   Field names below MUST match exactly what the admin panel writes to
   Firestore (see admin panel's "brandingPayload"):
     - headerText       -> site name shown in header
     - headerIcon       -> custom logo image URL (Imgbb link etc.)
     - footerCopyright  -> footer text

   LOGO LOGIC:
   - Default state (page just loaded / Firestore not yet responded):
     "logo-container" keeps showing the "Y" letter already in the HTML.
   - Once Firestore settings load and contain "headerIcon": the "Y" text
     is replaced with an <img> pointing to that custom URL, exactly like
     the app icons already do — with onerror falling back to the "Y"
     letter again if the custom URL fails to load.
   ========================================================================== */

/**
 * Applies branding coming from Firestore settings document.
 * Any field not present falls back to the existing default, so nothing
 * ever renders blank or broken.
 */
function updateStorefrontBranding(data) {
    try {
        if (!data) {
            applyDefaultBranding();
            return;
        }

        const titleText = document.getElementById('header-title-text');
        const logoBox = document.getElementById('logo-container');
        const footerText = document.getElementById('footer-copyright-text');

        if (data.headerText) {
            if (titleText) titleText.textContent = data.headerText;
            document.title = document.title.includes(' - ')
                ? document.title.replace(/^.*? - /, data.headerText + ' - ')
                : data.headerText;
        }

        // Logo: switch from the default "Y" letter to the admin-panel
        // custom logo URL (headerIcon) once it's available. Falls back
        // to the "Y" letter automatically if the custom URL fails to load.
        if (logoBox) {
            if (data.headerIcon) {
                const fallbackLetter = data.headerText ? data.headerText.trim().charAt(0).toUpperCase() : 'Y';
                logoBox.innerHTML = `<img src="${data.headerIcon}" alt="${data.headerText || 'YOMO STORE'}" style="width: 100%; height: 100%; object-fit: cover; border-radius: inherit;" onerror="this.parentElement.innerHTML='${fallbackLetter}';">`;
            } else {
                logoBox.textContent = data.headerText ? data.headerText.trim().charAt(0).toUpperCase() : 'Y';
            }
        }

        if (data.footerCopyright && footerText) {
            footerText.textContent = data.footerCopyright;
        }
    } catch (e) {
        console.error('updateStorefrontBranding error:', e);
        applyDefaultBranding();
    }
}

/**
 * Ensures sensible default branding is shown when Firestore settings
 * are unavailable, slow, or fail to load — including the default "Y" logo.
 */
function applyDefaultBranding() {
    const titleText = document.getElementById('header-title-text');
    const logoBox = document.getElementById('logo-container');
    const footerText = document.getElementById('footer-copyright-text');

    if (titleText && !titleText.textContent.trim()) titleText.textContent = 'YOMO STORE';
    if (logoBox && !logoBox.textContent.trim() && !logoBox.querySelector('img')) {
        logoBox.textContent = 'Y';
    }
    if (footerText && !footerText.textContent.trim()) {
        footerText.textContent = '© 2026 YOMO STORE. All Rights Reserved.';
    }
}