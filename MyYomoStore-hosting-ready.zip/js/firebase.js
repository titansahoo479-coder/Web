/* ==========================================================================
   Firebase Service Manager — Dynamic Auto-Initializer
   Safely initializes Firebase only if the SDK and config loaded correctly.
   Every consumer (api.js) checks getFirestoreDb() for null before use,
   so a Firebase/network failure never breaks the rest of the site —
   it just falls back to local demo data.
   ========================================================================== */

let db = null;
let isFirebaseActive = false;

function initFirebaseService() {
    try {
        if (typeof firebase !== 'undefined' && typeof firebaseConfig !== 'undefined' && firebaseConfig.apiKey) {
            if (!firebase.apps.length) {
                firebase.initializeApp(firebaseConfig);
            }
            db = firebase.firestore();
            isFirebaseActive = true;
        } else {
            console.warn('Firebase SDK or config not available yet — will retry on demand.');
        }
    } catch (e) {
        console.error('Firebase Service Initialization Error:', e);
        isFirebaseActive = false;
    }
    return db;
}

function getFirestoreDb() {
    if (!db) {
        initFirebaseService();
    }
    return db;
}

// Attempt an initial init; if the Firebase SDK hasn't finished loading yet
// (deferred script), getFirestoreDb() will safely retry the next time
// it's called from api.js / download.js.
initFirebaseService();
