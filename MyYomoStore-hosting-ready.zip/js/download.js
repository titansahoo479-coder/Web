/* ==========================================================================
   Download Page Controller
   - Reads ?app= / ?id= query params fresh on every load (works on refresh
     and on directly-opened / shared links, not just client-side navigation)
   - 1.5s failsafe guard with local fallback data
   - Realtime Firestore sync
   - Error UI with retry button if nothing could be loaded at all
   ========================================================================== */

let downloadFailsafeTimer = null;
let isAppRendered = false;

document.addEventListener('DOMContentLoaded', () => {
    initTheme();

    try {
        subscribeSettings(
            (data) => updateStorefrontBranding(data),
            () => applyDefaultBranding()
        );
    } catch (e) {
        console.error('subscribeSettings error:', e);
        applyDefaultBranding();
    }

    initDownloadPageApp();

    if (window.lucide) lucide.createIcons();
});

function initDownloadPageApp() {
    isAppRendered = false;

    // Query params are read fresh here every time this runs, so a hard
    // refresh or a directly-opened / shared URL works exactly like normal
    // in-app navigation.
    const appId = getQueryParam('id');
    const appSlug = getQueryParam('app');

    if (!appId && !appSlug) {
        showDownloadError('No app was specified in the link.');
        return;
    }

    // 1.5s Strict Guard
    downloadFailsafeTimer = setTimeout(() => {
        if (!isAppRendered) {
            useLocalDownloadFallback(appId, appSlug);
        }
    }, 1500);

    let activeDb = null;
    try {
        activeDb = getFirestoreDb();
    } catch (e) {
        console.error('getFirestoreDb error:', e);
    }

    if (activeDb) {
        try {
            activeDb.collection('apps').onSnapshot((snapshot) => {
                if (isAppRendered) return;

                let matchedApp = null;
                const targetSlug = appSlug ? decodeURIComponent(appSlug).toLowerCase().replace(/\s+/g, '-') : '';

                snapshot.forEach((doc) => {
                    const data = doc.data();
                    const docId = doc.id;
                    const nameSlug = data.name ? data.name.toLowerCase().replace(/\s+/g, '-') : '';

                    if ((appId && docId === appId) ||
                        (targetSlug && (docId === targetSlug || nameSlug === targetSlug || nameSlug.includes(targetSlug)))) {
                        matchedApp = { id: docId, ...data };
                    }
                });

                if (matchedApp) {
                    isAppRendered = true;
                    clearTimeout(downloadFailsafeTimer);
                    renderDownloadDetails(matchedApp);
                } else if (snapshot.docs.length > 0) {
                    isAppRendered = true;
                    clearTimeout(downloadFailsafeTimer);
                    const firstDoc = snapshot.docs[0];
                    renderDownloadDetails({ id: firstDoc.id, ...firstDoc.data() });
                } else {
                    useLocalDownloadFallback(appId, targetSlug);
                }
            }, (error) => {
                console.error('Firestore onSnapshot error:', error);
                useLocalDownloadFallback(appId, appSlug);
            });
        } catch (e) {
            console.error('Firestore query error:', e);
            useLocalDownloadFallback(appId, appSlug);
        }
    } else {
        useLocalDownloadFallback(appId, appSlug);
    }
}

function useLocalDownloadFallback(appId, appSlug) {
    if (isAppRendered) return;
    isAppRendered = true;
    clearTimeout(downloadFailsafeTimer);

    const localData = (typeof localAppsData !== 'undefined') ? localAppsData : [];
    const targetSlug = (appSlug || '').toLowerCase().replace(/\s+/g, '-');
    const found = localData.find(a =>
        a.id === appId ||
        (a.name && a.name.toLowerCase().replace(/\s+/g, '-') === targetSlug)
    );

    if (found || localData.length > 0) {
        renderDownloadDetails(found || localData[0]);
    } else {
        showDownloadError('This app could not be found.');
    }
}

function renderDownloadDetails(app) {
    const skeletonLoader = document.getElementById('skeleton-loader');
    const detailsContainer = document.getElementById('download-details-container');

    if (skeletonLoader) skeletonLoader.style.display = 'none';
    if (!detailsContainer) return;

    document.title = `${app.name} - Download | YOMO STORE`;

    // Keep the URL clean and shareable/refreshable without altering
    // browser history (no extra back-button entries).
    const cleanSlug = app.name ? encodeURIComponent(app.name.toLowerCase().replace(/\s+/g, '-')) : 'app';
    if (window.history && window.history.replaceState) {
        window.history.replaceState(null, '', `download.html?app=${cleanSlug}&id=${encodeURIComponent(app.id)}`);
    }

    const appSize = app.size ? app.size : 'N/A';
    const appVersion = app.version ? app.version : 'v1.0.0';
    const androidVersion = app.androidVersion || app.os || 'Android N/A';
    const downloads = app.downloadsCount || app.downloads || '10K+';
    const description = app.description || 'Download the official verified version safely directly from YOMO STORE.';

    detailsContainer.style.display = 'block';
    detailsContainer.innerHTML = `
        <div class="breadcrumb">
            <a href="index.html">
                <i data-lucide="home" style="width: 14px; height: 14px;"></i>
                <span>Home</span>
            </a>
            <span class="breadcrumb-sep">&gt;</span>
            <span class="breadcrumb-active">Download</span>
        </div>

        <div class="app-detail-card">
            <img src="${app.icon}" class="detail-icon" alt="${app.name}" onerror="this.src='https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?w=150&q=80'">

            <div>
                <div class="detail-title">${app.name}</div>
                <div class="app-version" style="margin: 4px auto 0 auto;">${appVersion}</div>
            </div>

            <div class="detail-meta-grid">
                <div class="meta-item">
                    <span class="meta-label">Size</span>
                    <span class="meta-value">${appSize}</span>
                </div>
                <div class="meta-item">
                    <span class="meta-label">OS</span>
                    <span class="meta-value">${androidVersion}</span>
                </div>
                <div class="meta-item">
                    <span class="meta-label">Downloads</span>
                    <span class="meta-value">${downloads}</span>
                </div>
            </div>

            <div class="detail-description">
                ${description}
            </div>

            <button class="btn-download btn-full" id="btn-start-download" onclick="triggerDownloadFlow(this, '${app.download}')">
                <i data-lucide="download" style="width: 18px; height: 18px;"></i>
                <span>Download Now</span>
            </button>
        </div>
    `;

    if (window.lucide) lucide.createIcons();
}

/**
 * Shows a friendly error state with a retry button, instead of leaving
 * the page stuck on the loading skeleton forever.
 */
function showDownloadError(message) {
    const skeletonLoader = document.getElementById('skeleton-loader');
    const detailsContainer = document.getElementById('download-details-container');

    if (skeletonLoader) skeletonLoader.style.display = 'none';
    if (!detailsContainer) return;

    detailsContainer.style.display = 'block';
    detailsContainer.innerHTML = `
        <div class="app-detail-card" style="text-align:center;">
            <i data-lucide="alert-triangle" style="width: 48px; height: 48px; color: #4F46E5;"></i>
            <div class="detail-title" style="margin-top: 8px;">Something went wrong</div>
            <p style="font-size: 14px; color: var(--text-muted); margin: 8px 0 16px;">${message}</p>
            <button class="btn-download btn-full" id="btn-retry-download">
                <i data-lucide="refresh-cw" style="width: 18px; height: 18px;"></i>
                <span>Retry</span>
            </button>
            <a href="index.html" class="btn-download btn-full" style="margin-top: 10px; background: transparent; border: 1px solid var(--border-color, #333);">
                <i data-lucide="home" style="width: 18px; height: 18px;"></i>
                <span>Back to Home</span>
            </a>
        </div>
    `;

    if (window.lucide) lucide.createIcons();

    const retryBtn = document.getElementById('btn-retry-download');
    if (retryBtn) {
        retryBtn.addEventListener('click', () => {
            if (skeletonLoader) skeletonLoader.style.display = '';
            detailsContainer.style.display = 'none';
            initDownloadPageApp();
        });
    }
}

function triggerDownloadFlow(btn, downloadUrl) {
    if (btn.classList.contains('loading')) return;

    btn.classList.add('loading');
    const originalHTML = btn.innerHTML;

    btn.innerHTML = `<i data-lucide="loader-2" class="spin-icon" style="width: 18px; height: 18px;"></i> <span>Downloading...</span>`;
    if (window.lucide) lucide.createIcons();

    setTimeout(() => {
        btn.innerHTML = `<i data-lucide="shield-check" style="width: 18px; height: 18px; color: #10B981;"></i> <span style="color:#10B981;">Secured</span>`;
        if (window.lucide) lucide.createIcons();

        setTimeout(() => {
            window.open(downloadUrl || '#', '_blank');

            btn.classList.remove('loading');
            btn.innerHTML = originalHTML;
            if (window.lucide) lucide.createIcons();
        }, 800);
    }, 1600);
}
