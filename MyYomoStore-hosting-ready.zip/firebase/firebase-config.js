/* Firebase Configuration */
const firebaseConfig = {
  apiKey: "AIzaSyDTctjFs_EgF8jVvmcYnYiy94TqY7ghQnw",
  authDomain: "yomo-store-2026.firebaseapp.com",
  databaseURL: "https://yomo-store-2026-default-rtdb.firebaseio.com",
  projectId: "yomo-store-2026",
  storageBucket: "yomo-store-2026.firebasestorage.app",
  messagingSenderId: "955925511423",
  appId: "1:955925511423:web:6ae71cd5aa1976f048a0ca"
};

// Initialize Firebase if the SDK has already loaded by this point.
// firebase.js also calls this defensively, so load order between the two
// doesn't matter.
if (typeof firebase !== 'undefined') {
    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }
}
